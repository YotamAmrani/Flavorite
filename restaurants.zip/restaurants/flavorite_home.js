
var promise = document.querySelector('audio').play();

if (promise !== undefined) {
    promise.then(_ => {
        // Autoplay started!
    }).catch(error => {
    	console.log("error");
        // Autoplay was prevented.
        // Show a "Play" button so that user can start playback.
    });
}